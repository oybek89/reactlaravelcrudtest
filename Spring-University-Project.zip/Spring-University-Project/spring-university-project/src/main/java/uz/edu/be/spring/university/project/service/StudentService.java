package uz.edu.be.spring.university.project.service;


import uz.edu.be.spring.university.project.model.Student;

import java.util.List;
import java.util.Optional;

/**
 * Created By hamdamboy
 * Project: spring-demo-start
 * Date: 27/09/22
 * Email: hamdamboy.urunov@gmail.com
 */
public interface StudentService {
     public Student saveStudent(Student student1);
     public List<Student> fetchStudentList();
     Optional<Student> getOnlyStudentById(Long id);
     Student updateStudentInfo(Long id, Student student);
     void deleteStudentId(Long studentId);
     Student fetchStudentByFirstName(String firstName);

     List<Student> fetchStudentByLastNames(String lastName);

     Student internationalByName(String firstName);
}
