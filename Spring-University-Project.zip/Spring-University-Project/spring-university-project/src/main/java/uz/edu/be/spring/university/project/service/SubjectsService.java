package uz.edu.be.spring.university.project.service;


import uz.edu.be.spring.university.project.model.Subjects;

/**
 * Created By hamdamboy
 * Project: spring-demo-start
 * Date: 01/10/22
 * Email: hamdamboy.urunov@gmail.com
 */
public interface SubjectsService {

    public Subjects saveSubjects(Subjects subjects);
}
