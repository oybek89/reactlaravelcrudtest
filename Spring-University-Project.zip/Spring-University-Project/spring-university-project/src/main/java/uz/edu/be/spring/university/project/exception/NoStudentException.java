package uz.edu.be.spring.university.project.exception;

/**
 * Created By hamdamboy
 * Project: spring-demo-start
 * Date: 24/09/22
 * Email: hamdamboy.urunov@gmail.com
 */
public class NoStudentException {
}
