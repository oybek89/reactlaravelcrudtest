package uz.edu.be.spring.university.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.edu.be.spring.university.project.model.Student;
import uz.edu.be.spring.university.project.repository.StudentRepository;


import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Created By hamdamboy
 * Project: spring-demo-start
 * Date: 27/09/22
 * Email: hamdamboy.urunov@gmail.com
 */
@Service
public class StudentServiceImpl implements StudentService{

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public Student saveStudent(Student student1) {
        return studentRepository.save(student1);
    }

    @Override
    public List<Student> fetchStudentList() {
        return studentRepository.findAll();
    }

    @Override
    public Optional<Student> getOnlyStudentById(Long id) {
        return studentRepository.findById(id);
    }

    @Override
    public Student updateStudentInfo(Long id, Student student) {
        Student studentDB = studentRepository.findById(id).get();

        if (Objects.nonNull(student.getFirstName()) &&
                !"".equalsIgnoreCase(student.getFirstName())){
            studentDB.setFirstName(student.getFirstName());
        }
        if (Objects.nonNull(student.getLastName()) &&
                !"".equalsIgnoreCase(student.getLastName())){
            studentDB.setLastName(student.getLastName());
        }
        return studentRepository.save(studentDB);
    }

    @Override
    public void deleteStudentId(Long studentId) {
        if (Objects.nonNull(studentId)) {
            studentRepository.deleteById(studentId);
        } else{
            System.out.println("Student already delete");
        }
    }

    @Override
    public Student fetchStudentByFirstName(String firstName) {
        return studentRepository.findByFirstName(firstName);
    }

    @Override
    public List<Student> fetchStudentByLastNames(String lastName) {


        return (List<Student>) studentRepository.findByLastName(lastName);
    }

    @Override
    public Student internationalByName(String firstName) {
        //logic
        return null;
    }


}
