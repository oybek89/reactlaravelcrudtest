package uz.edu.be.spring.university.project.exception;

/**
 * Created By hamdamboy
 * Project: spring-university-project
 * Date: 04/10/22
 * Email: hamdamboy.urunov@gmail.com
 */
public class NoUniversityException {
}
