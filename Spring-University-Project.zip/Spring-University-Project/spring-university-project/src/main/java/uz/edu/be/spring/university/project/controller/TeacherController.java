package uz.edu.be.spring.university.project.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * Created By hamdamboy
 * Project: spring-university-project
 * Date: 04/10/22
 * Email: hamdamboy.urunov@gmail.com
 */
@RestController
public class TeacherController {
}
